package io.castled.channel.inapp.models.enums;

public enum InAppMessageType {

    MODAL,
    FULL_SCREEN,
    SLIDE_UP,
    CUSTOM_HTML
}
