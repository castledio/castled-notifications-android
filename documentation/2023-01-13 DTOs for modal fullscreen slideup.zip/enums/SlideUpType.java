package io.castled.channel.inapp.models.enums;

public enum SlideUpType {

    DEFAULT
}