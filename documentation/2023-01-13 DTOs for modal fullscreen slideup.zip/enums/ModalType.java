package io.castled.channel.inapp.models.enums;

public enum ModalType {

    DEFAULT,
    IMG_AND_BUTTONS,
    TEXT_AND_BUTTONS,
    IMG_ONLY
}
