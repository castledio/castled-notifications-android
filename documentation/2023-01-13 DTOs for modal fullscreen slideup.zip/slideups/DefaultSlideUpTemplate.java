package io.castled.channel.inapp.models.slideups;

import io.castled.channel.inapp.models.enums.SlideUpType;
import io.castled.channel.notificationcommons.enums.ClickAction;
import lombok.*;

@NoArgsConstructor
public class DefaultSlideUpTemplate extends BaseSlideUpTemplate {

    private String imageUrl;
    private ClickAction clickAction;
    private String url;

    private String body;
    private String bgColor;
    private Long fontSize;
    private String fontColor;

    @Builder
    public DefaultSlideUpTemplate(String imageUrl, ClickAction clickAction, String url, String body, String fontColor,
                                  Long fontSize, String bgColor) {
        super(SlideUpType.DEFAULT);
        this.imageUrl = imageUrl;
        this.clickAction = clickAction;
        this.url = url;
        this.body = body;
        this.fontColor = fontColor;
        this.fontSize = fontSize;
        this.bgColor = bgColor;
    }
}
