package io.castled.channel.inapp.models.slideups;

import io.castled.channel.inapp.models.InAppMessageTemplate;
import io.castled.channel.inapp.models.enums.InAppMessageType;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
public class SlideUpMessageTemplate extends InAppMessageTemplate {

    private BaseSlideUpTemplate slideUp;

    @Builder
    public SlideUpMessageTemplate(BaseSlideUpTemplate slideUp) {
        super(InAppMessageType.SLIDE_UP);
        this.slideUp = slideUp;
    }
}
