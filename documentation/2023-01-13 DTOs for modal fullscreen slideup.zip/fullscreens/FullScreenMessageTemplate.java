package io.castled.channel.inapp.models.fullscreens;

import io.castled.channel.inapp.models.InAppMessageTemplate;

import io.castled.channel.inapp.models.enums.InAppMessageType;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
public class FullScreenMessageTemplate extends InAppMessageTemplate {

    private BaseFullScreenTemplate fs;

    @Builder
    public FullScreenMessageTemplate(BaseFullScreenTemplate fs) {
        super(InAppMessageType.FULL_SCREEN);
        this.fs = fs;
    }
}
