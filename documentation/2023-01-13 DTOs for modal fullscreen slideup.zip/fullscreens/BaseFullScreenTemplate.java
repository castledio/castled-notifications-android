package io.castled.channel.inapp.models.fullscreens;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import io.castled.channel.inapp.models.enums.FullScreenType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.EXISTING_PROPERTY,
        visible = true,
        property = "type")
@JsonSubTypes({
        @JsonSubTypes.Type(value = DefaultFullScreenTemplate.class, name = "DEFAULT"),
        @JsonSubTypes.Type(value = ImgAndButtonsFullScreenTemplate.class, name = "IMG_AND_BUTTONS"),
        @JsonSubTypes.Type(value = TextAndButtonsFullScreenTemplate.class, name = "TEXT_AND_BUTTONS"),
        @JsonSubTypes.Type(value = ImgOnlyFullScreenTemplate.class, name = "IMG_ONLY")
})
public class BaseFullScreenTemplate {

    private FullScreenType type;
}
