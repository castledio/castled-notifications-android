package io.castled.channel.inapp.models.fullscreens;

import io.castled.channel.notificationcommons.enums.ClickAction;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ImgOnlyFullScreenTemplate extends BaseFullScreenTemplate {

    private String imageUrl;
    private ClickAction defaultClickAction;

    private String screenOverlayColor;
}