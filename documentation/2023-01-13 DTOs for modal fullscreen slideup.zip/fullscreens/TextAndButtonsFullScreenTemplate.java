package io.castled.channel.inapp.models.fullscreens;

import io.castled.channel.inapp.models.InAppActionButton;
import io.castled.channel.notificationcommons.enums.ClickAction;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TextAndButtonsFullScreenTemplate extends BaseFullScreenTemplate {

    private ClickAction defaultClickAction;

    private String title;
    private String body;
    private String fontColor;
    private Long fontSize;
    private String bgColor;

    private String screenOverlayColor;

    List<InAppActionButton> actionButtons;
}
