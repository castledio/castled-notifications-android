package io.castled.channel.inapp.models.modals;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import io.castled.channel.inapp.models.enums.ModalType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.EXISTING_PROPERTY,
        visible = true,
        property = "type")
@JsonSubTypes({
        @JsonSubTypes.Type(value = DefaultModalTemplate.class, name = "DEFAULT"),
        @JsonSubTypes.Type(value = ImgAndButtonsModalTemplate.class, name = "IMG_AND_BUTTONS"),
        @JsonSubTypes.Type(value = TextAndButtonsModalTemplate.class, name = "TEXT_AND_BUTTONS"),
        @JsonSubTypes.Type(value = ImgOnlyModalTemplate.class, name = "IMG_ONLY")
})
public class BaseModalTemplate {

    private ModalType type;
}
