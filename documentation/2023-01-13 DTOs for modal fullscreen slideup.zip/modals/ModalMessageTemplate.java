package io.castled.channel.inapp.models.modals;

import io.castled.channel.inapp.models.InAppMessageTemplate;
import io.castled.channel.inapp.models.enums.InAppMessageType;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
public class ModalMessageTemplate extends InAppMessageTemplate {

    private BaseModalTemplate modal;

    @Builder
    public ModalMessageTemplate(BaseModalTemplate modal) {
        super(InAppMessageType.MODAL);
        this.modal = modal;
    }
}
