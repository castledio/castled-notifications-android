package io.castled.channel.inapp.models.modals;

import io.castled.channel.inapp.models.InAppActionButton;
import io.castled.channel.inapp.models.enums.ModalType;
import io.castled.channel.notificationcommons.enums.ClickAction;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class DefaultModalTemplate extends BaseModalTemplate {

    private String imageUrl;
    private ClickAction defaultClickAction;
    private String url;

    private String title;
    private String body;
    private String fontColor;
    private Long fontSize;
    private String bgColor;

    private String screenOverlayColor;

    List<InAppActionButton> actionButtons;

    @Builder
    public DefaultModalTemplate(String imageUrl, ClickAction defaultClickAction, String url, String title, String body,
                                String fontColor, Long fontSize, String bgColor, String screenOverlayColor,
                                List<InAppActionButton> inAppActionButtons) {
        super(ModalType.DEFAULT);
        this.imageUrl = imageUrl;
        this.defaultClickAction = defaultClickAction;
        this.url = url;
        this.title = title;
        this.body = body;
        this.fontColor = fontColor;
        this.fontSize = fontSize;
        this.bgColor = bgColor;
        this.screenOverlayColor = screenOverlayColor;
        this.actionButtons = inAppActionButtons;
    }
}
