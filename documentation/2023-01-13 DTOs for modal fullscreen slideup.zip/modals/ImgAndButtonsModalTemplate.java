package io.castled.channel.inapp.models.modals;

import io.castled.channel.inapp.models.InAppActionButton;
import io.castled.channel.notificationcommons.enums.ClickAction;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ImgAndButtonsModalTemplate extends BaseModalTemplate {

    private String imageUrl;
    private ClickAction defaultClickAction;
    private String url;

    private String screenOverlayColor;

    List<InAppActionButton> actionButtons;
}
